document.addEventListener('DOMContentLoaded', function() {
    const cadastroCard = document.getElementById('cadastroCard');
    const loginCard = document.getElementById('loginCard');
    const cadastroLink = document.getElementById('cadastroLink');
    const loginLink = document.getElementById('loginLink');
  
    cadastroLink.addEventListener('click', function(event) {
      event.preventDefault();
      toggleForms();
    });
  
    loginLink.addEventListener('click', function(event) {
      event.preventDefault();
      toggleForms();
    });
  
    const cadastroForm = document.getElementById('cadastroForm');
    const loginForm = document.getElementById('loginForm');
  
    cadastroForm.addEventListener('submit', function(event) {
      event.preventDefault();
      cadastrar();
    });
  
    loginForm.addEventListener('submit', function(event) {
      event.preventDefault();
      entrar();
    });
  });
  
  function toggleForms() {
    const cadastroCard = document.getElementById('cadastroCard');
    const loginCard = document.getElementById('loginCard');
    
    cadastroCard.classList.toggle('hidden');
    loginCard.classList.toggle('hidden');
  }
  
  function cadastrar() {
    const nome = document.getElementById('nome').value;
    const sobrenome = document.getElementById('sobrenome').value;
    const cpf = document.getElementById('cpf').value;
    const senha = document.getElementById('senha').value;
    const confirmSenha = document.getElementById('confirmSenha').value;
  
    const nomeError = document.getElementById('nomeError');
    const sobrenomeError = document.getElementById('sobrenomeError');
    const cpfError = document.getElementById('cpfError');
    const senhaError = document.getElementById('senhaError');
    const confirmSenhaError = document.getElementById('confirmSenhaError');
    const successMessage = document.getElementById('successMessage');
  
    let hasError = false;
  
    // Validar Nome
    if (nome.trim() === '') {
      nomeError.textContent = 'Nome é obrigatório';
      hasError = true;
    } else {
      nomeError.textContent = '';
    }
  
    // Validar Sobrenome
    if (sobrenome.trim() === '') {
      sobrenomeError.textContent = 'Sobrenome é obrigatório';
      hasError = true;
    } else {
      sobrenomeError.textContent = '';
    }
  
    // Validar CPF
    const cpfRegex = /^\d{11}$/;
    if (!cpfRegex.test(cpf)) {
      cpfError.textContent = 'CPF inválido';
      hasError = true;
    } else {
      cpfError.textContent = '';
    }
  
    // Validar Senha
    const senhaRegex = /^(?=.*[A-Z])(?=.*\d).{8,}$/;
    if (!senhaRegex.test(senha)) {
      senhaError.textContent = 'Senha deve conter pelo menos 8 caracteres, uma letra maiúscula e um número';
      hasError = true;
    } else {
      senhaError.textContent = '';
    }
  
    // Confirmar Senha
    if (senha !== confirmSenha) {
      confirmSenhaError.textContent = 'As senhas não coincidem';
      hasError = true;
    } else {
      confirmSenhaError.textContent = '';
    }
  
    if (!hasError) {
      // Simular um tempo de cadastramento
      successMessage.textContent = 'Cadastrando...';
      setTimeout(function() {
        // Salvar usuário no localStorage
        const usuario = { nome, sobrenome, cpf, senha };
        const usuarios = JSON.parse(localStorage.getItem('usuarios')) || [];
        usuarios.push(usuario);
        localStorage.setItem('usuarios', JSON.stringify(usuarios));
  
        successMessage.textContent = ' ';
        limparCamposCadastro();
        toggleForms();
      }, 1500); // Tempo em milissegundos
    }
  }
  
  function limparCamposCadastro() {
    document.getElementById('nome').value = '';
    document.getElementById('sobrenome').value = '';
    document.getElementById('cpf').value = '';
    document.getElementById('senha').value = '';
    document.getElementById('confirmSenha').value = '';
    document.querySelectorAll('.error-message').forEach(elem => elem.textContent = '');
  }
  
  function entrar() {
    const cpf = document.getElementById('loginCpf').value;
    const senha = document.getElementById('loginSenha').value;
  
    const usuarios = JSON.parse(localStorage.getItem('usuarios')) || [];
  
    // Verificar se o CPF e senha correspondem a algum usuário cadastrado
    const usuario = usuarios.find(u => u.cpf === cpf && u.senha === senha);
  
    if (usuario) {
      alert('Login bem-sucedido!');
      limparCamposLogin();
    } else {
      alert('CPF ou senha incorretos. Tente novamente.');
    }
  }
  
  function limparCamposLogin() {
    document.getElementById('loginCpf').value = '';
    document.getElementById('loginSenha').value = '';
  }
  
  